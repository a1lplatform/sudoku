﻿namespace Gley.About
{
    using Gley.Common;
    using System.Collections.Generic;

    [System.Serializable]
    public class AssetVersions
    {
        public List<AssetVersion> assetsVersion = new List<AssetVersion>();
    }
}
